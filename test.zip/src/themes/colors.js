export default COLORS = {
  robin_s_egg_blue: "#90f7ec",
  tealish: "#32ccbc",
  gray: "#d8d8d8",
  topaz: "#1cc8b6",
  white2: "#ebebeb",
  purply_pink: "#f790e7",
  steel: "#8e8e93"
};